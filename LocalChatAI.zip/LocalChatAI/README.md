# LocalChat

Android chat app with a ChatGPT-like dark interface and a fully local GGUF model.

- Engine: llama.cpp via `dev.ffmpegkit-maintained:llama-android:0.1.1`
- Model: SmolLM2-135M-Instruct Q3_K_M (downloaded on first launch, ~93.5 MB)
- Thinking levels: aus / schnell / tief (implemented as different local system prompts + token budgets)
- Voice input via Android SpeechRecognizer
- Text-to-speech for answers
- New chat, copy answer, local history for current session

The model is intentionally downloaded instead of bundled, so the APK stays much smaller.

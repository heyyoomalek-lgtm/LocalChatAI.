package com.malek.localchatai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import dev.ffmpegkit.llama.Llama
import dev.ffmpegkit.llama.LlamaConfig
import dev.ffmpegkit.llama.LlamaModel
import kotlinx.coroutines.*
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.*

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var send: TextView
    private lateinit var status: TextView
    private lateinit var thinking: Spinner
    private var model: LlamaModel? = null
    private var busy = false
    private var tts: TextToSpeech? = null
    private val history = mutableListOf<Pair<String, String>>()

    private val modelName = "SmolLM2-135M-Instruct-Q3_K_M.gguf"
    private val modelUrl = "https://huggingface.co/tensorblock/SmolLM2-135M-Instruct-GGUF/resolve/main/$modelName"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        ensureModel()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(text: String, size: Float, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(getColor(R.color.text))
        if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(getColor(R.color.bg)) }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(8), dp(10), dp(8)) }
        val title = tv("LocalChat", 20f, true)
        top.addView(title, LinearLayout.LayoutParams(0, dp(52), 1f))

        val newBtn = tv("＋", 29f, false).apply { gravity = Gravity.CENTER; setOnClickListener { newChat() } }
        top.addView(newBtn, LinearLayout.LayoutParams(dp(52), dp(52)))
        val menuBtn = tv("⋯", 26f).apply { gravity = Gravity.CENTER; setOnClickListener { showMenu() } }
        top.addView(menuBtn, LinearLayout.LayoutParams(dp(44), dp(52)))
        root.addView(top)

        val thinkRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), 0, dp(14), dp(8)) }
        val thinkLabel = tv("Denken", 13f, true); thinkLabel.setTextColor(getColor(R.color.muted))
        thinkRow.addView(thinkLabel, LinearLayout.LayoutParams(dp(58), dp(38)))
        thinking = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("aus", "schnell", "tief"))
        }
        thinkRow.addView(thinking, LinearLayout.LayoutParams(dp(120), dp(40)))
        status = tv("modell wird vorbereitet…", 12f).apply { setTextColor(getColor(R.color.muted)); gravity = Gravity.CENTER_VERTICAL }
        thinkRow.addView(status, LinearLayout.LayoutParams(0, dp(38), 1f))
        root.addView(thinkRow)

        scroll = ScrollView(this).apply { isFillViewport = true }
        chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(18)) }
        scroll.addView(chat)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val composer = LinearLayout(this).apply { setPadding(dp(10), dp(8), dp(10), dp(10)); gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply {
            hint = "Nachricht schreiben…"; hintTextColor = getColor(R.color.muted); setTextColor(getColor(R.color.text)); textSize = 16f
            setSingleLine(false); minLines = 1; maxLines = 5; background = getDrawable(R.drawable.bg_input); padding = android.graphics.Rect(dp(14), dp(2), dp(8), dp(2))
        }
        composer.addView(input, LinearLayout.LayoutParams(0, dp(54), 1f))
        val mic = tv("⌕", 24f).apply { gravity = Gravity.CENTER; setOnClickListener { voiceInput() } }
        composer.addView(mic, LinearLayout.LayoutParams(dp(48), dp(54)))
        send = tv("➤", 22f, true).apply { gravity = Gravity.CENTER; setOnClickListener { sendMessage() } }
        composer.addView(send, LinearLayout.LayoutParams(dp(54), dp(54)))
        root.addView(composer)
        setContentView(root)

        addAssistant("yo. ich bin deine lokale KI. kein cloud-api nötig.")
    }

    private fun addMessage(text: String, user: Boolean, onSpeak: (() -> Unit)? = null) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = if (user) Gravity.END else Gravity.START; setPadding(0, dp(4), 0, dp(4)) }
        val bubble = TextView(this).apply {
            this.text = text; textSize = 16f; setTextColor(getColor(R.color.text)); setPadding(dp(13), dp(10), dp(13), dp(10))
            background = getDrawable(if (user) R.drawable.bg_user else R.drawable.bg_assistant); setTextIsSelectable(true)
        }
        val max = (resources.displayMetrics.widthPixels * .86f).toInt()
        row.addView(bubble, LinearLayout.LayoutParams(max, ViewGroup.LayoutParams.WRAP_CONTENT))
        if (!user) {
            val tools = LinearLayout(this).apply { gravity = Gravity.START }
            val copy = tv("kopieren", 11f).apply { setTextColor(getColor(R.color.muted)); setPadding(dp(4),dp(3),dp(10),dp(3)); setOnClickListener { (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("antwort", text)) } }
            tools.addView(copy)
            val speak = tv("vorlesen", 11f).apply { setTextColor(getColor(R.color.muted)); setPadding(dp(4),dp(3),dp(10),dp(3)); setOnClickListener { onSpeak?.invoke() ?: speak(text) } }
            tools.addView(speak)
            row.addView(tools)
        }
        chat.addView(row)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun addAssistant(text: String) = addMessage(text, false)

    private fun ensureModel() {
        val f = File(getExternalFilesDir("models"), modelName)
        if (f.exists()) { loadModel(f); return }
        status.text = "modell: 0%"
        scope.launch(Dispatchers.IO) {
            try {
                f.parentFile?.mkdirs()
                val c = URL(modelUrl).openConnection() as HttpURLConnection
                c.instanceFollowRedirects = true; c.connectTimeout = 15000; c.readTimeout = 30000
                c.connect()
                if (c.responseCode !in 200..299) error("HTTP ${c.responseCode}")
                val total = c.contentLengthLong
                c.inputStream.use { input ->
                    f.outputStream().use { out ->
                        val buf = ByteArray(1024 * 1024); var done = 0L; var n: Int
                        while (input.read(buf).also { n = it } > 0) {
                            out.write(buf, 0, n); done += n
                            withContext(Dispatchers.Main) { if (total > 0) status.text = "modell: ${(done*100/total)}%" }
                        }
                    }
                }
                withContext(Dispatchers.Main) { loadModel(f) }
            } catch (e: Exception) {
                f.delete(); withContext(Dispatchers.Main) { status.text = "modell-download fehlgeschlagen"; addAssistant("das modell konnte nicht geladen werden. internet kurz anmachen und die app nochmal öffnen.") }
            }
        }
    }

    private fun loadModel(file: File) {
        status.text = "modell wird geladen…"
        scope.launch {
            try {
                val threads = maxOf(2, Runtime.getRuntime().availableProcessors().coerceAtMost(6))
                model = withContext(Dispatchers.IO) { Llama.loadModel(file.absolutePath, LlamaConfig(contextSize = 2048, threads = threads)) }
                status.text = "lokal bereit"
                addAssistant("bereit. ich rechne jetzt direkt auf dem handy.")
            } catch (e: Exception) { status.text = "modellfehler"; addAssistant("modellfehler: ${e.message ?: "unbekannt"}") }
        }
    }

    private fun sendMessage() {
        val text = input.text.toString().trim(); if (text.isEmpty() || busy || model == null) return
        input.setText(""); addMessage(text, true); busy = true; send.text = "■"
        scope.launch {
            try {
                val level = thinking.selectedItem?.toString() ?: "aus"
                val system = when (level) {
                    "tief" -> "Du bist eine hilfreiche lokale KI. Prüfe deine Antwort intern sorgfältig und gib nur das Ergebnis aus. Keine private Gedankenkette zeigen. Antworte klar auf Deutsch."
                    "schnell" -> "Du bist eine schnelle lokale KI. Antworte kurz und nützlich auf Deutsch."
                    else -> "Du bist eine hilfreiche lokale KI. Antworte natürlich und verständlich auf Deutsch."
                }
                history.add("user" to text)
                val prompt = history.takeLast(8).joinToString("\n") { (r,m) -> if (r == "user") "User: $m" else "Assistant: $m" }
                val result = withContext(Dispatchers.IO) { Llama.complete(model!!, prompt = prompt, systemPrompt = system, maxTokens = if (level == "tief") 300 else 180) }
                history.add("assistant" to result.text)
                addAssistant(result.text.trim())
            } catch (e: Exception) { addAssistant("fehler beim antworten: ${e.message ?: "unbekannt"}") }
            busy = false; send.text = "➤"
        }
    }

    private fun newChat() { history.clear(); chat.removeAllViews(); addAssistant("neuer chat. was geht?") }

    private fun showMenu() {
        PopupMenu(this, findViewById(android.R.id.content)).apply {
            menu.add("gespeicherter chat: nur lokal")
            menu.add("modell: SmolLM2 135M Q3_K_M")
            menu.add("engine: llama.cpp")
            setOnMenuItemClickListener { true }
        }.show()
    }

    private fun voiceInput() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 44); return }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE") }
        startActivityForResult(i, 45)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 45 && resultCode == RESULT_OK) { input.setText(data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: ""); input.requestFocus() }
    }

    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "localchat") }
    override fun onInit(statusCode: Int) { if (statusCode == TextToSpeech.SUCCESS) tts?.language = Locale.GERMANY }
    override fun onDestroy() { scope.cancel(); tts?.shutdown(); model?.let { runCatching { Llama.releaseModel(it) } }; super.onDestroy() }
}
